/*********
This is the final code that integrates all the subsystems (digipot (MCP4161, adc (MCP3008), lcd, and switches to the PMIC)
********/

#include <at89c5131.h>
#include "digipot.h"
#include "spi.h"
#include "lcd.h"
#include "adc.h"

int resis;
int min_bit;
int max_bit;

// Setting the default, min and max resistance respectively
unsigned long int def_resistance = 500;  
unsigned long int low_res = 100;		
unsigned long int high_res = 35000;  		

int j = 0;
unsigned int adc_data = 0;

code unsigned char display_msg1[] = "Fine inc ";
code unsigned char display_msg2[] = "Fine dec ";
code unsigned char display_msg3[] = "Course inc ";
code unsigned char display_msg4[] = "Course dec ";
code unsigned char display_msg5[] = "Hit minimum ";
code unsigned char display_msg6[] = "Hit maximum ";

code unsigned char display_txt1[] = "Volt.: ";
code unsigned char display_txt2[] = " mV";

char data_ascii[6] = {0, 0, 0, 0, 0, '\0'};
char bit_ascii[6] = {0, 0, 0, 0, 0, '\0'};

//Specifying the pins for the input switches 
sbit inc = P3^4;
sbit dec = P3^5;
sbit mode = P3^6;

void main(void){
	
	digipot_init();
	spi_init();
	lcd_init();
	adc_init();
	
	mode = 0;
	inc = 0;
	dec = 0;
	
	resis = def_resistance*256/100000;
	min_bit = low_res*256/100000;
	max_bit = high_res*256/100000; // Limiting the maximum resistance so as to keep the voltage across the pins of MCP4161 within the prescribed 3.6V range
	
	// Loop to update the value of the digipot and obtain the required voltage according to the inputs given
	while(1){
			//collecting the value from adc
			unsigned int x;
			x = adc(7);							   
			adc_data = (unsigned int)((x * 3.2258 * 4.95) - 0.13);

			msdelay(100);
			int_to_string(resis,bit_ascii);
		
			lcd_cmd(0x80)	;
		
		//Now checking for updates
		//first line prints the voltage
		//second line prints the resis bit
		
			if(mode == 1){//fine control
				
				if(inc == 1 && dec == 0){//fine increase
					resis += 1;
					lcd_cmd(0x01);
					lcd_write_string(display_txt1);
					int_to_string(adc_data, data_ascii);
					lcd_write_string(data_ascii);
					lcd_write_string(display_txt2);
					lcd_cmd(0xC0);
					lcd_write_string(display_msg1);
					lcd_write_string(bit_ascii);
					msdelay(100);
				}
				else if(inc == 0 && dec == 1){//fine decrease
					resis -= 1;
					lcd_cmd(0x01);
					lcd_write_string(display_txt1);
					int_to_string(adc_data, data_ascii);
					lcd_write_string(data_ascii);
					lcd_write_string(display_txt2);
					lcd_cmd(0xC0);
					lcd_write_string(display_msg2);
					lcd_write_string(bit_ascii);
					msdelay(100);
				}
			}
			else if(mode == 0) {//course control
				
				if(inc == 1 && dec == 0){//course increase
					resis += 5;
					lcd_cmd(0x01);
					lcd_write_string(display_txt1);
					int_to_string(adc_data, data_ascii);
					lcd_write_string(data_ascii);
					lcd_write_string(display_txt2);
					lcd_cmd(0xC0);
					lcd_write_string(display_msg3); 
				  lcd_write_string(bit_ascii);
					msdelay(100);
				}
				else if(inc == 0 && dec == 1){//course decrease
					resis -= 5;
					lcd_cmd(0x01);
					lcd_write_string(display_txt1);
					int_to_string(adc_data, data_ascii);
					lcd_write_string(data_ascii);
					lcd_write_string(display_txt2);
					lcd_cmd(0xC0);
					lcd_write_string(display_msg4);
					lcd_write_string(bit_ascii);
					msdelay(100);
				}
				
			}
			
			if(resis < min_bit){ // Checking for the min limit
				resis = min_bit;
				lcd_cmd(0x01);
				lcd_write_string(display_txt1);
				int_to_string(adc_data, data_ascii);
				lcd_write_string(data_ascii);
				lcd_write_string(display_txt2);
				lcd_cmd(0xC0);
				lcd_write_string(display_msg5);
				lcd_write_string(bit_ascii);
				msdelay(100);
			}
			
			else if(resis > max_bit){ // Checking for the max limit
				resis = max_bit;
				lcd_cmd(0x01);
				lcd_write_string(display_txt1);
				int_to_string(adc_data, data_ascii);
				lcd_write_string(data_ascii);
				lcd_write_string(display_txt2);
				lcd_cmd(0xC0);
				lcd_write_string(display_msg6);
				lcd_write_string(bit_ascii);
				msdelay(100);
			}
digipot_write(resis);	// Writing the value of wiper resistance bit to digipot for updation
	}
	
}