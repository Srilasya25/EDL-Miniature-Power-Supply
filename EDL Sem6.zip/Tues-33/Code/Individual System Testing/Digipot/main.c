/*********************************************************************
This is the test for the digipot mcp4162 using  the spi already given
**********************************************************************/

#include <at89c5131.h>
#include "digipot.h"
#include "spi.h"
#include "lcd.h"

unsigned int resis;
unsigned int i;

void main(void)
{

	spi_init();       // initialize SPI interface
  digipot_init();   // initialize digipot

	for (i = 1; i <150; i = i+4){
		resis = i;
		digipot_write(resis);
		msdelay(1000);
	}
	
}
