#include <at89c5131.h>
#include "digipot.h"
#include "spi.h"
#include <stdio.h>

unsigned long int command;


sbit cs_digipot = P3^1;                                                    

void digipot_init(void)
{
    cs_digipot=1;
}

void digipot_write(unsigned long int value){
    
    command = 0x1100;       // Command Byte to set mode and potentiometer
    cs_digipot=0;               // Set CS low to start transmission
    spi_trx(command);
    spi_trx(value);
    cs_digipot=1;
    
}
