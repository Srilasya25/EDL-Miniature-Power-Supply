/**********************************************************
This header file contains function related uC 8051 SPI module. 
It has functions to initialize spi module and to communicate with SPI slave 
***********************************************************/

//preprocessor directives for guarding against multiple inclusion of header files, read compiler user guide for more information

#ifndef spi_h																						//if identifier spi_h is not defined then goto next line
#define spi_h 1																				//Define spi_h identifier and assign constant 1 to it 
#include <at89c5131.h>

void spi_init(void);																		//Initialize SPI module 
unsigned long int spi_trx(unsigned long int spi_data_tx);				//Takes 3 bytes as an input and send it to SPI slave IC and returns 3 bytes which are received from slave
int spi_trx_byte(int spi_data_tx);
void spi_interrupt(void);																//SPI ISR 																												



#endif																									//end if directive

//Declaration of functions which are contained in this header file

