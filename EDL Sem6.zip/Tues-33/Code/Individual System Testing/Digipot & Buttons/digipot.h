#ifndef digipot_h                                                                        
#define digipot_h
                
#include <at89c5131.h>
								
void digipot_init(void);                                                        
void digipot_write(unsigned long int);                                                                                         


#endif  